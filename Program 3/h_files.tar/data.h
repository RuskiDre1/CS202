#include "header.h"
// Olympic Tracker
// data.h
// Andrey Toderyan
/* 08/05/21
	
  This is the main header file for the hierchaywhich will include
  BST of LLL Exception Handling in Olympic Tracker

*/
class lll_node
{
	public:
		lll_node();
		lll_node(const lll_node &);
		~lll_node();

		int display();
		int input();
		


	protected:
		athlete * an_athlete;
		lll_node * next;
	

};
class bst_node
{
	public: 
		bst_node();
		bst_node(const bst_node & );
		~bst_node();

		int display_lll(); // calls Overloaded " << " operator while going through bst
		int input();
		
		// = 
		bst_node & operator = (const bst_node & source);
		
		//display
		friend ostream & operator << (ostream & out, const bst_node & a_athlete);
		// input 
		friend istream & operator >> (istream & in, bst_node & new_node);	
	
		//if another bst_node name is < > to balance correctly				
		friend bool operator < (const bst_node, const bst_node);
		friend bool operator > (const bst_node, const bst_node);

	
		/*	
		friend bool operator <= (const node, const node);
		friend bool operator >= (const node, const node);
		friend bool operator != (const node, const node);
		*/

	

	protected:
		bst_node * left;
		bst_node * right;
	
		athlete * an_athlete;
		lll_node * head;

};
class bst
{
	public:
		bst();
		~bst();

		int menu();
		int input();
		int display_all();
		int balance();

	protected:
		bst_node * root;
	
};

