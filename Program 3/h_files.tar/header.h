#include <iostream>
#include <cctype>
#include <cstring>
#include <string>

using namespace std;
// Olympic Tracker
// header.h
// Andrey Toderyan
/* 08/05/21
	
  This is the main header file for the hierchay which will include
  dynamic binding and Exception Handling in Olympic Tracker

*/
class athlete
{
	public:
		athlete();
		athlete(const athlete &);
		~athlete();
		
		virtual int display();//  
		virtual int input(); // 

			

	protected:
		string name;
		
		
};
class dash: public athlete
{
	public:
		dash();
		dash(const dash &);
		~dash();
		
		int display();//  
		int input(); // 

	protected:
		string time;
		
};
class relay: public athlete
{
	public:
		relay();
		~relay();
		relay(const relay &);
		
		int display();//
		int input(); //

	protected:
		string time;
};
class long_m: public athlete
{
	public:
		long_m();
		long_m(const long_m &);
		~long_m();
		
		int display();//  
		int input(); // 

	protected:
		string time;
};















