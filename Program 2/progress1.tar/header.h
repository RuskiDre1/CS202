#include <iostream>
#include <cctype>
#include <cstring>
// Colonial Game
// header.h
// Andrey Toderyan
/* 07/20/21
	
  This is the main header file for the hierchay which will include
  dynamic binding for the Colonial Game

*/

class civil
{
	public:
		civil();
		
		civil(const civil & source);
		virtual~civil();
		
		virtual bool activate(); // run the civilization
		virtual bool explain(); // explain the basics of this group 
		virtual int  attack(); //  attacking and return said damage
		virtual int  trade(); // trading and how much you profit/lost
		
		
	protected:
		string moto;
		int currency;
		int health;
		string name;
		int power; // soldiers
		
};

class usa: public civil
{
	public:
		usa();
		usa(const usa & );
		~usa();
		
		bool activate();
		bool explain();
		int  attack(); 
		int trade();

	protected:
		int colonies;
		int timber;
};

class brit: public civil
{
	public:
		brit();
		brit(const brit & souce);	
		~brit();

		bool activate();
		bool explain();
		int  attack(); 
		int trade();
	

	protected:
		int tea;
};
class french: public civil
{
	public:
		french();
		french(const french & source);
		~french();

		bool activate();
		bool explain();
		int  set_penalty();


	protected:
		int clothe;
};












