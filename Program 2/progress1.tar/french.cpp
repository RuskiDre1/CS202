#include "data.h"
// french.cpp
// Andrey Toderyan 
/* 07/20/21
	
  This is the implementation for class french

	protected:
		int clothe;
};



*/
french::french()
{


}
french::french(const french & source)
{


}
french::~french()
{

}
bool french::activate()
{

}

bool french::explain()
{

}
int french::set_penalty()
{

}




