#include "data.h"
// usa.cpp
// Andrey Toderyan 
/* 07/20/21
	
  This is the implementation for class usa


	protected:
		int colonies;
		int timber;
*/

usa::usa()
{

}
usa::usa(const usa & )
{

}
usa::~usa()
{

}
bool usa::activate()
{

}
bool usa::explain()
{

}
int  usa::attack()
{

}
int usa::trade()
{

}

