

#include "data.h"
// main.cpp
// Andrey Toderyan 
/* 07/20/21
	
  This is the main cpp  file for the hierchay which will include
  dynamic binding for the Colonial Game

*/
int main()
{
	do
	{
	



	}while(again());

}
bool again()
{
	cout << endl << "Create and run a New course (Y/N)" << endl;
        char ans; cin >> ans; cin.ignore(100,'\n');

        if(toupper(ans) == 'Y')
                return true;
        return false;
}
