#include "data.h"
// brit.cpp
// Andrey Toderyan 
/* 07/20/21
	
  This is the implementation for class brit

	

	protected:
		int tea;
}*/
brit::brit()
{

}

brit::brit(const brit & souce)
{

}
brit::~brit()
{


}
bool brit::activate()
{

}
bool brit::explain()
{

}
int brit::attack()
{


}
int brit::trade()
{

}

