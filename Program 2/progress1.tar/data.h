#include "header.h"

// Colonial Game
// data.h
// Andrey Toderyan
/* 07/20/21
	
  This is the main header file for the data structures which will include
  dynamic binding for the Colonial Game

*/

