#include "data.h"
// civil.cpp
// Andrey Toderyan 
/* 07/20/21
	
  This is the implementation for class civil

	protected:
		string moto;
		int currency;
		int health;
		string name;
		int power; // soldiers
*/
civil::civil()
{

}
civil::civil(const civil & source)
{

}
civil::virtual~civil()
{

}
		
virtual bool civil::activate() // run the civilization
{

}

virtual bool civil::explain() // explain the basics of this group 
{

}

virtual int civil::attack() //  attacking and return said damage
{

}

virtual int civil::trade() // trading and how much you profit/lost
{

}
		



















