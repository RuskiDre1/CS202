#include "data.h"
//concert.cpp
// andrey toderyan
/* 06/23/21
	
	this is implementation for the concert  class and concert node


	protected:
		string venue;
		string preformer;

	
*/




concert::concert() //default constructor
{

}

concert::~concert() //destructor
{

}
concert::concert(const concert & ) // CC
{

}


concert::concert(string & name, char * date): person(name, date)
{}
		
bool concert::add()
{
	return false;
}

bool concert::display()
{
	return false;
}
/*-------------------------------------------------------------------*/

node_concert::node_concert() //default constructor
{

}
node_concert::~node_concert() //destructor
{

}
node_concert::node_concert(const node_concert & ) // CC
{

}

void node_concert::set_next(node_concert * source)
{
	return;
}
node_concert * & node_concert::go_next()
{
	return next;
}

concert_list::concert_list()
{
	rear = NULL;
}
concert_list::~concert_list()
{


}

int concert_list::add (const concert & source)
{
	return 0;
}
int concert_list::display_all()
{
	return 0;
}
int concert_list::remove_all()
{
	return 0;
}
int concert_list::remove(char * )
{
	return 0;
}
int concert_list::remove(node_concert * & head, char * key)
{
	return 0;
}
int concert_list::display_all(node_concert * head)
{
	return 0;

}


