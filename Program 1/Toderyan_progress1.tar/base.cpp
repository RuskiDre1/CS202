#include "header.h"

//base.cpp
// andrey toderyan
/* 06/23/21
	
	this is implementation for the base class

	protected:
		char * title;
		char * date;
		char * time;

*/
base::base(): title(NULL) , date(NULL) , time(NULL) // default constructor
{}
base::base(char * date_): date(date_)
{


}
base::~base()     // destructor 
{
	
}
base::base( const base & source) // copy constructor
{
		
}
bool base::input()
{
	cout << "Base input() called" << endl;
	return false;
}

bool base::remove()
{
	cout << "base remove() called " << endl;
	return false;
}

bool base::display()
{
	cout << "base display() called " << endl;
	return false;
}

	


