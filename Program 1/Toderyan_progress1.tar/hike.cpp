#include "data.h"
//hike.cpp
// andrey toderyan
/* 06/23/21
	
	this is implementation for the hike class and hike node


	protected:
		int altitude;
		int lenght;
*/
hike::hike() // default constructor
{

}
hike::~hike() // destructor
{

}
hike::hike(const hike & ) // CC
{

}
hike::hike(string & name, char * date): person(name,date)
{}
bool hike::add()
{
	return false;
}

bool hike::display()
{
	return false;
}


