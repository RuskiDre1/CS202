#include "data.h"
//lake.cpp
// andrey toderyan
/* 06/23/21
	
	this is implementation for the lake class and lake node


	protected:
		string kind;
		bool lifeguard;
		int depth;
*/

person::person(): name(NULL)
{}

person::~person()
{}
person::person(const base & )
{

}

person::person(string & name_, char * date): base(date), name(name_)
{} 

bool person::input(string &)
{
	return false;
}
bool person::display()
{
	cout << "Name: " << name;
	return true;
}
bool person::remove()
{
	return false;
}
/*--------------------------------------------------------------------------------*/

lake::lake() : kind(NULL) , lifeguard (false), depth(0) //default contructor
{
	cout << "Lake Contructor called " << endl;

}
lake::~lake()//destructor
{
	cout << "Lake Destructor called " << endl;
}

lake::lake(const lake & source) // CC
{
	//cout << "Lake C.C  called " << endl;
} 
lake::lake(string & name, char * date): person(name, date)
{

}
bool lake::add()
{
	cout << "Lake add()  called " << endl;

	return false;
}
bool lake::display()
{
	cout << "Lake Display()  called " << endl;

	return false;
}
bool lake::compare()
{
	cout << "Lake compare()  called " << endl;

	return false;
}
// DATA STRUCTURE TIME ! 

node_lake::node_lake()  //default contructor
{}

node_lake::~node_lake() {}//destructor

node_lake::node_lake(const node_lake & source){} // CC

node_lake::node_lake(string & name, char * date): lake(name, date){}

/*--------------------------------------------------------------------*/
//       lake_list ** lake_event;	

lake_list::lake_list()
{
	lake_event = NULL;
}

lake_list::~lake_list()
{
	// call remove all func to clear the Array of LLL
}

int lake_list::add (const node_lake & source)
{

	return 0;
}


int lake_list::display_all()
{

	return 0;
}

int lake_list::remove_all()
{

	return 0;
}
int lake_list::remove(char * )
{

	return 0;
}

int lake_list::remove(node_lake * & head, char * key)
{

	return 0;
}

int lake_list::display_all(node_lake * head)
{
	return 0;
}















