#include "header.h"

//base.cpp
// andrey toderyan
/* 06/23/21
	
	this is implementation for the base class

	protected:
		char * title;
		char * date;
		char * time;

*/
base::base(): title(NULL) , date(NULL) , time(NULL) // default constructor
{}
base::base(char * date_): date(date_)
{
	input();
}
base::~base()     // destructor 
{
	cout << "PASSED BASE DE " << endl;
}
base::base( const base & source) // copy constructor
{
	title = new char[strlen(source.title) + 1];
	strcpy(title, source.title);
	time = new char[strlen(source.time) + 1];
	strcpy(time, source.time);
	date = new char[strlen(source.date) + 1];
	strcpy(date, source.date);
}
bool base::input()
{
	cout << "Base input() called" << endl;
	
	char t[100];
	char d[100];
	char time[100];

	cout << "Title of Event: ";
	cin >> t; cin.ignore(100, '\n');

	cout << "Date ? ";
	cin >> d;

	cout << "Time: ";
	cin >>time;

	return false;
}

bool base::remove()
{
	cout << "base remove() called " << endl;
	return false;
}

bool base::display()
{
	cout << "base display() called " << endl;

	cout << "Event Title: " << title << endl
	     << "Date:        " << date  << endl
	     << "time:        " << time  << endl;

	return true;
}



























